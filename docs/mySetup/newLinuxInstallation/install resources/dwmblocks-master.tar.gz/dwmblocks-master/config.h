//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/	/*Command*/		/*Update Interval*/	/*Update Signal*/
	/*Icon*/	/*Command*/		/*Update Interval*/	/*Update Signal*/
	{" ", "sensors | awk '/^fan1:/ {print $2 }'  ",				5,		0},
	{" ", "sensors | awk '/^Package id 0: */ {print +$4 }'   ",				5,		0},
	{" ", "ip -4 -o addr show wlp2s0: | awk '{print $4}'  ",				60,		0},
	{" ", "free -g | awk '/^Mem:/{print $3 }'  ",				5,		0},
	{" ", "amixer sget Master | awk -F '[][]' 'END{ print  $2 }'   ",				5,		0},
	{" ", "date +'%H:%M %m/%d'   ",				5,		0},
};

//sets delimeter between status commands. NULL character ('\0') means no delimeter.
static char *delim = " | ";

// Have dwmblocks automatically recompile and run when you edit this file in
// vim with the following line in your vimrc/init.vim:

// autocmd BufWritePost ~/.local/src/dwmblocks/config.h !cd ~/.local/src/dwmblocks/; sudo make install && { killall -q dwmblocks;setsid dwmblocks & }
